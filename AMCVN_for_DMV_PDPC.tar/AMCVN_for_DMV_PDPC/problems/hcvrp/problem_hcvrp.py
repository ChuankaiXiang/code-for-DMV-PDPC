from torch.utils.data import Dataset
import torch
import os
import pickle
from problems.hcvrp.state_hcvrp import StateHCVRP
from utils.beam_search import beam_search
import math
import random
import pandas as pd
import numpy as np

class HCVRP(object):
    NAME = 'hcvrp'
    @staticmethod
    def get_costs(dataset, obj, pi, tour, acc_late, acc_subs,acc_lengths):

        LATE_COST_PENALTY = 1
        SUBSIDY_RATE = 1

        Size = pi.size()
        num_veh = len(tour)
        loc_with_start = torch.cat((dataset['veh_start'], dataset['locs']), 1)  # batch_size, graph_size+1, 2

        dis_to_dest = []
        for i in range(num_veh):
            last_visit_node, _ = torch.stack(tour[i], -1).max(-1)
            last_visit_loc = loc_with_start.gather(1, last_visit_node[:, None, None].expand(loc_with_start.size(0), 1,
                                                                                            loc_with_start.size(
                                                                                                -1))).squeeze()
            last_dis = (last_visit_loc - dataset['veh_destination'][:, i]).norm(p=2, dim=1).unsqueeze(-1)
            dis_to_dest.append(last_dis)

        last_dis_ = torch.cat(dis_to_dest, dim=-1)
        tour_dis_ = last_dis_ + acc_lengths
        total_cost = tour_dis_ + LATE_COST_PENALTY * acc_late.squeeze(-1) + SUBSIDY_RATE*acc_subs.squeeze(-1)

        if obj == 'min-max':
            total_cost, maxindex= torch.max(total_cost, dim=1)
            tour_cost = tour_dis_.gather(1, maxindex[:,None].expand(tour_dis_.size(0),  1)).squeeze()
            acc_late = acc_late.squeeze(-1).gather(1, maxindex[:,None].expand(tour_dis_.size(0),  1)).squeeze()
            acc_subs = acc_subs.squeeze(-1).gather(1, maxindex[:,None].expand(tour_dis_.size(0),  1)).squeeze()
            return total_cost,tour_cost,acc_late,acc_subs,None
        if obj == 'min-sum':
            return torch.sum(total_cost, dim=1), torch.sum(tour_dis_, dim=1), torch.sum(acc_late.squeeze(-1),dim=1),torch.sum(acc_subs.squeeze(-1),dim=1), None
    @staticmethod
    def make_dataset(*args, **kwargs):
        return HCVRPDataset(*args, **kwargs)

    @staticmethod
    def make_state(*args, **kwargs):
        return StateHCVRP.initialize(*args, **kwargs)

    @staticmethod
    def beam_search(input, beam_size, expand_size=None,
                    compress_mask=False, model=None, max_calc_batch_size=4096):
        assert model is not None, "Provide model"

        fixed = model.precompute_fixed(input)

        def propose_expansions(beam):
            return model.propose_expansions(
                beam, fixed, expand_size, normalize=True, max_calc_batch_size=max_calc_batch_size
            )

        state = HCVRP.make_state(
            input, visited_dtype=torch.int64 if compress_mask else torch.uint8
        )

        return beam_search(state, beam_size, propose_expansions)


def make_instance(args):
    locs,veh_start,veh_destination,dems,durs,rdys,ldts,aprs,veh_aprs,veh_exps,veh_speed, *args = args
    return {
        'locs': torch.tensor(locs,dtype=torch.float),
        'veh_start': torch.tensor(veh_start,dtype=torch.float),
        'veh_destination': torch.tensor(veh_destination,dtype=torch.float),
        'dems':torch.tensor(dems,dtype=torch.float),
        'durs':torch.tensor(durs,dtype=torch.float),
        'rdys':torch.tensor(rdys,dtype=torch.float),
        'ldts':torch.tensor(ldts,dtype=torch.float),
        'aprs':torch.tensor(aprs,dtype=torch.float),
        'veh_aprs':torch.tensor(veh_aprs,dtype=torch.float),
        'veh_exps':torch.tensor(veh_exps,dtype=torch.float),
        'veh_speed':torch.tensor(veh_speed,dtype=torch.float)
             }


class HCVRPDataset(Dataset):

    def __init__(self, filename=None,
            num_samples=10000,
            offset=0,
            cust_count = 100,
            veh_count = 25,
            veh_capa = 200,
            veh_speed = 1,
            cust_loc_range = (0,101),
            cust_dem_range = (5,41),
            horizon = 480,
            cust_dur_range = (10,31),
            tw_ratio = 0.5,
            cust_tw_range = (30,91),
            deg_of_dy = 0.5,
            deg_of_veh_dy=0.5,
            d_early_ratio=0.5,
            distribution=None):
        super(HCVRPDataset, self).__init__()

        self.data_set = []
        if filename is not None:
            assert os.path.splitext(filename)[1] == '.pkl'

            with open(filename, 'rb') as f:
                data = pickle.load(f)
            self.data = [make_instance(args) for args in data[offset:offset + num_samples]]

        else:

            data = []
            path = 'data/transportation_nodes/node.csv'
            for i in range(num_samples):
                veh_speed = 5
                locations = pd.read_csv(path, header=0,
                                        usecols=["Longitude", "Latitude"
                                                 ]).values
                locations = np.array(locations)
                # 先一步标准化一下下
                locations[:, 0] = locations[:, 0] - 73.5
                dy_veh_count = int(veh_count * deg_of_veh_dy)
                sel_node_num = cust_count * 2 + dy_veh_count * 2+2

                selected_points = locations[:sel_node_num, :]
                for i in range(sel_node_num, len(locations)):
                    r = random.randint(0, i)
                    if r < sel_node_num:
                        selected_points[r, :] = locations[i, :]

                nodes = torch.from_numpy(selected_points).float()

                locs = nodes[:cust_count * 2, :]

                dy_veh_start = nodes[cust_count * 2:cust_count * 2 + dy_veh_count, :]
                dy_veh_destination = nodes[cust_count * 2 + dy_veh_count:cust_count * 2 + dy_veh_count * 2, :]
                st_veh_start = nodes[cust_count * 2 + dy_veh_count * 2:cust_count * 2 + dy_veh_count * 2+1,:].expand(veh_count-dy_veh_count,2)
                st_veh_destination = nodes[cust_count * 2 + dy_veh_count * 2+1:cust_count * 2 + dy_veh_count * 2 + 2, :].expand(veh_count-dy_veh_count,2)
                veh_start = torch.cat((st_veh_start,dy_veh_start),0)
                veh_destination = torch.cat((st_veh_destination,dy_veh_destination),0)

                dems_pick = torch.randint(*cust_dem_range, (cust_count,1), dtype=torch.float)
                dems_del = - dems_pick
                dems = torch.cat((dems_pick,dems_del),0)
                durs = torch.randint(*cust_dur_range, (cust_count*2, 1), dtype=torch.float)

                if isinstance(deg_of_dy, float):
                    is_dyn = torch.empty((cust_count,1)).bernoulli_(deg_of_dy)
                elif len(deg_of_dy) == 1:
                    is_dyn = torch.empty(deg_of_dy).bernoulli_(deg_of_dy[0])
                else:  # tuple of float
                    ratio = torch.tensor(deg_of_dy)[torch.randint(0, len(deg_of_dy), (1,), dtype=torch.int64)]
                    is_dyn = ratio[:, None].expand((cust_count, 1)).bernoulli()

                if isinstance(d_early_ratio, float):
                    is_dyn_e = torch.empty((cust_count,1)).bernoulli_(d_early_ratio)
                elif len(d_early_ratio) == 1:
                    is_dyn_e = torch.empty((cust_count,1)).bernoulli_(d_early_ratio[0])
                else:
                    ratio = torch.tensor(d_early_ratio)[
                        torch.randint(0, len(d_early_ratio), (1,), dtype=torch.int64)
                    ]
                    is_dyn_e = ratio[:,None].expand((cust_count,1)).bernoulli()

                pick_aprs = is_dyn * is_dyn_e * torch.randint(1, horizon // 3 + 1, (cust_count,1), dtype=torch.float) \
                       + is_dyn * (1 - is_dyn_e) * torch.randint(horizon // 3 + 1, 2 * horizon // 3 + 1, (cust_count,1),
                                                                 dtype=torch.float)
                del_aprs = pick_aprs
                aprs = torch.cat((pick_aprs,del_aprs),0)


                veh_st_aprs = torch.tensor(0,dtype=torch.float).expand(veh_count-dy_veh_count,1)
                veh_st_exps = torch.tensor(horizon,dtype=torch.float).expand(veh_count-dy_veh_count,1)
                veh_dy_aprs = torch.randint(1, horizon // 3 + 1, (dy_veh_count,1), dtype=torch.float)
                veh_dy_exps = torch.randint(horizon // 2 + 1, horizon, (dy_veh_count, 1), dtype=torch.float)
                veh_aprs = torch.cat((veh_st_aprs,veh_dy_aprs),0)
                veh_exps = torch.cat((veh_st_exps,veh_dy_exps),0)
                shuf_veh_dys = torch.cat((veh_aprs,veh_exps),-1)
                shuff = torch.randperm(shuf_veh_dys.size(0))
                shuf_veh_dys = shuf_veh_dys[shuff]
                veh_aprs = shuf_veh_dys[:, 0]
                veh_exps = shuf_veh_dys[:, 1]
                veh_exps_index = veh_exps == horizon
                veh_exps[veh_exps_index] = math.inf  # 自有车辆赋值一个大值作为过期时间
                veh_start = veh_start[shuff]
                veh_destination = veh_destination[shuff]



                if isinstance(tw_ratio, float):
                    has_tw = torch.empty((cust_count, 1)).bernoulli_(tw_ratio)
                elif len(tw_ratio) == 1:
                    has_tw = torch.empty((cust_count, 1)).bernoulli_(tw_ratio[0])
                else:  # tuple of float
                    ratio = torch.tensor(tw_ratio)[torch.randint(0, len(tw_ratio), (1,), dtype=torch.int64)]
                    has_tw = ratio[:, None].expand((cust_count, 1)).bernoulli()

                tws_pick = (1 - has_tw) * torch.full(( cust_count, 1), horizon) \
                           + has_tw * torch.randint(*cust_tw_range, ( cust_count, 1), dtype=torch.float)
                tws_deli = (1 - has_tw) * torch.full(( cust_count, 1), horizon) \
                           + has_tw * torch.randint(*cust_tw_range, ( cust_count, 1), dtype=torch.float)
                tws = torch.cat((tws_pick, tws_deli), 0)

                centroid = torch.mean(veh_start, dim=0)
                pick_tts = (centroid[None,None,:]- locs[:cust_count,None, :]).pow(2).sum(-1).pow(0.5)/veh_speed
                del_tts_ = (locs[:cust_count,None, :]- locs[cust_count:,None, :]).pow(2).sum(-1).pow(0.5)/veh_speed
                del_tts = pick_tts+del_tts_



                pick_rdys = has_tw[:cust_count, :] * (aprs[:cust_count, :] + torch.rand(cust_count, 1) * (horizon - torch.max(pick_tts + durs[:cust_count, :], tws[:cust_count, :]) - aprs[:cust_count, :]))

                del_rdys = pick_rdys + del_tts
                rdys = torch.cat((pick_rdys, del_rdys), 0)

                rdys.floor_()
                ldts = rdys + tws
                # ldts_index = ldts>480
                # ldts[ldts_index] = 480


                ##normalize###
                loc_scl, loc_off = torch.cat((locs,veh_start,veh_destination),0)[:,:].max().item(),torch.cat((locs,veh_start,veh_destination),0)[:,:].min().item()
                loc_scl -= loc_off
                t_scl = ldts[:, :].max().item()

                locs -= loc_off
                locs /= loc_scl
                veh_start -= loc_off
                veh_start /= loc_scl
                veh_destination -= loc_off
                veh_destination /= loc_scl

                dems /= veh_capa

                durs /= t_scl
                rdys /= t_scl
                ldts /= t_scl
                aprs /= t_scl
                veh_aprs /= t_scl
                veh_exps /= t_scl

                veh_speed = torch.tensor(veh_speed,dtype=torch.float32)

                sample = {
                    'locs': locs,
                    'veh_start': veh_start,
                    'veh_destination': veh_destination,
                    'dems':dems,
                    'durs':durs,
                    'rdys':rdys,
                    'ldts':ldts,
                    'aprs':aprs,
                    'veh_aprs':veh_aprs,
                    'veh_exps':veh_exps,
                    'veh_speed':veh_speed

                }
                data.append(sample)
            self.data = data




        self.size = len(self.data)  # num_samples

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        return self.data[idx]  # index of sampled data


