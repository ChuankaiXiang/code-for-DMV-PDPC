import torch
from typing import NamedTuple
from utils.boolmask import mask_long2bool, mask_long_scatter



class StateHCVRP(NamedTuple):

    locs: torch.Tensor  # Depot + loc, [batch_size, graph_size+1, 2]
    dems: torch.Tensor
    durs: torch.Tensor
    rdys: torch.Tensor
    ldts: torch.Tensor
    aprs: torch.Tensor
    veh_aprs : torch.Tensor
    veh_exps : torch.Tensor
    veh_star: torch.Tensor
    veh_dest: torch.Tensor
    veh: torch.Tensor  # numver of vehicles
    veh_rema_capa: torch.Tensor
    veh_spes:torch.Tensor
    veh_cur_time: torch.Tensor
    veh_acc_late: torch.Tensor
    veh_acc_subs:torch.Tensor
    veh_prev_a: torch.Tensor
    veh_masks : torch.Tensor
    ids: torch.Tensor  # Keeps track of original fixed data index of rows
    visited_: torch.Tensor  # Keeps track of nodes that have been visited
    lengths: torch.Tensor
    i: torch.Tensor  # Keeps track of step


    @property
    def visited(self):
        if self.visited_.dtype == torch.uint8:
            return self.visited_
        else:
            return self.visited_[:, None, :].expand(self.visited_.size(0), 1, -1).type(torch.ByteTensor)

    @property
    def dist(self):  # coords: []
        return (self.locs[:, :, None, :] - self.locs[:, None, :, :]).norm(p=2, dim=-1)

    def __getitem__(self, key):
        if torch.is_tensor(key) or isinstance(key, slice):  # If tensor, idx all tensors by this tensor:
            return self._replace(
                ids=self.ids[key],
                veh=self.veh[key],
                veh_rema_capa=self.veh_rema_capa[key],
                veh_cur_time=self.veh_cur_time[key],
                veh_prev_a=self.veh_prev_a[key],
                visited_=self.visited_[key],
                lengths=self.lengths[key],
                veh_masks=self.veh_masks[key],
                veh_acc_late = self.veh_acc_late,
                veh_acc_subs = self.veh_acc_subs
            )
        return super(StateHCVRP, self).__getitem__(key)


    @staticmethod
    def initialize(input, visited_dtype=torch.uint8):


        loc = input['locs']
        veh_star = input['veh_start']
        veh_dest = input['veh_destination']
        dems = input['dems'].transpose(1, 2)
        durs = input['durs']
        rdys = input['rdys']
        ldts = input['ldts']
        aprs = input['aprs'].transpose(1, 2)
        veh_aprs = input['veh_aprs']
        veh_exps = input['veh_exps']
        veh_spes = input['veh_speed']
        batch_size, n_loc, _ = loc.size()  # n_loc = graph_size
        veh_num = veh_star.size(1)
        veh_prev_a = torch.zeros(batch_size, veh_num,dtype=torch.long, device=loc.device)

        for i in range(veh_num):
            veh_prev_a[:, i] = i
        return StateHCVRP(
            locs=torch.cat((veh_star, loc), -2), # [batch_size, graph_size, 2]]  size 512*21
            dems = torch.cat((torch.zeros(dems.size(0),dems.size(1),veh_num,device=dems.device),dems),-1),
            durs = torch.cat((torch.zeros(durs.size(0),veh_num,durs.size(2),device=durs.device),durs),1),
            rdys = torch.cat((torch.zeros(rdys.size(0),veh_num,rdys.size(2),device=rdys.device),rdys),1),
            ldts = torch.cat((torch.ones(ldts.size(0),veh_num,ldts.size(2),device=ldts.device),ldts),1),
            aprs=torch.cat((torch.zeros(aprs.size(0), dems.size(1),veh_num, device=aprs.device), aprs), -1),
            veh_aprs = veh_aprs,
            veh_exps = veh_exps,
            veh_star = veh_star,
            veh_dest = veh_dest,
            veh_rema_capa = torch.ones(batch_size, veh_num, 1, device=loc.device),
            veh_spes = veh_spes,
            veh_cur_time= veh_aprs[:,:,None],
            veh_acc_late= torch.zeros(batch_size, veh_num, 1, device=loc.device),
            veh_acc_subs=torch.zeros(batch_size, veh_num, 1, device=loc.device),
            ids=torch.arange(batch_size, dtype=torch.int64, device=loc.device)[:, None],  # Add steps dimension
            veh=torch.arange(veh_num, dtype=torch.int64, device=loc.device)[:, None], # tensor([0,1,2,...,len(StateHCVRP.VEHICLE_CAPACITY)-1])
            veh_prev_a = veh_prev_a,
            visited_= torch.cat([torch.ones(batch_size, 1, veh_num,dtype=torch.uint8, device=loc.device)
                      if visited_dtype == torch.uint8
                      else torch.ones(batch_size, 1, (veh_num + 63) // 64, dtype=torch.int64, device=loc.device),torch.zeros(batch_size, 1, n_loc,dtype=torch.uint8, device=loc.device)
                      if visited_dtype == torch.uint8
                      else torch.zeros(batch_size, 1, (n_loc + 63) // 64, dtype=torch.int64, device=loc.device) ],2 ),
            lengths=torch.zeros(batch_size, veh_num, device=loc.device),
            i=torch.zeros(1, dtype=torch.int64, device=loc.device),  # Vector with length num_steps
            veh_masks = torch.cat([torch.ones(batch_size, veh_num, n_loc // 2 + veh_num, dtype=torch.uint8, device=loc.device),
            torch.zeros(batch_size, veh_num, n_loc // 2, dtype=torch.uint8, device=loc.device)], dim=-1).expand(batch_size,veh_num, n_loc+veh_num) #这里n_loc 没有包含depot点 512*3*n_loc
        )



    def update(self, selected, veh,non_cus_index):  # [batch_size, num_veh]

        assert self.i.size(0) == 1, "Can only update if state represents single step"


        veh_num = selected.size(1)
        n_loc = self.veh_masks.size(-1) - veh_num  # number of customers
        batch_size, _ = selected.size()

        new_delivery = (selected[torch.arange(selected.size(0)), veh] + n_loc // 2) % (n_loc+veh_num)  # the pair node of selected node(512*1)


        prev_a = self.veh_prev_a.clone().cuda()
        veh_prev_coord = self.locs.gather(1,prev_a[:, :, None].expand(prev_a.size(0), veh_num, self.locs.size(-1)))


        prev_a[~non_cus_index.bool()] = selected[~non_cus_index.bool()]  # [batch_size, num_veh]



        cur_coord = self.locs.gather(1,selected[:, :, None].expand(selected.size(0), veh_num, self.locs.size(-1)))
        sel_cur_coord = cur_coord.gather(1, veh[:,None,None].expand(cur_coord.size(0),1 , cur_coord.size(2)))
        sel_veh_prev_cur_coord = veh_prev_coord.gather(1, veh[:,None,None].expand(veh_prev_coord.size(0),1 , veh_prev_coord.size(2)))
        sel_cur_tra_lengths = (sel_cur_coord- sel_veh_prev_cur_coord).norm(p=2, dim=-1)


        sel_cur_tra_lengths[non_cus_index]= 0

        lengths = self.lengths.clone().cuda()
        sel_veh_lengths = lengths.gather(1, veh[:,None].expand(lengths.size(0), 1))
        acc_sel_veh_lenghts = sel_veh_lengths + sel_cur_tra_lengths


        acc_lengths = lengths.scatter(1, veh[:, None], acc_sel_veh_lenghts)


        sel_veh_trav_time = sel_cur_tra_lengths/self.veh_spes[:,None]
        sel_veh_cur_time = self.veh_cur_time.gather(1, veh[:,None,None].expand(self.veh_cur_time.size(0),self.veh_cur_time.size(2) , 1))

        cur_loc_rdys = self.rdys.gather(1,selected[:, :, None].expand(selected.size(0), veh_num, self.rdys.size(-1)))
        sel_cur_loc_rdys = cur_loc_rdys.gather(1, veh[:,None,None].expand(cur_loc_rdys.size(0),cur_loc_rdys.size(2) , 1))

        sel_veh_arv_time = torch.max(sel_veh_cur_time + sel_veh_trav_time[:,:,None], sel_cur_loc_rdys)

        cur_loc_ldts = self.ldts.gather(1,selected[:, :, None].expand(selected.size(0), veh_num, self.ldts.size(-1)))
        sel_cur_loc_ldts = cur_loc_ldts.gather(1, veh[:,None,None].expand(cur_loc_ldts.size(0),cur_loc_ldts.size(2) , 1))


        sel_veh_late = (sel_veh_arv_time - sel_cur_loc_ldts).clamp_(min = 0)

        sel_veh_late[non_cus_index] = 0

        sel_veh_acc_late = self.veh_acc_late.gather(1, veh[:,None,None].expand(self.veh_acc_late.size(0),self.veh_acc_late.size(2) , 1))
        sel_acc_late = sel_veh_late + sel_veh_acc_late


        veh_acc_late = self.veh_acc_late.clone().cuda()
        acc_late = veh_acc_late.scatter(1, veh[:,None,None], sel_acc_late)

        durs = self.durs.gather(1,selected[:, :, None].expand(selected.size(0), veh_num, self.durs.size(-1)))
        sel_durs = durs.gather(1, veh[:,None,None].expand(durs.size(0),durs.size(2) , 1))

        sel_cur_time = sel_veh_arv_time + sel_durs


        sel_veh_exps = self.veh_exps.gather(1, veh[:,None].expand(self.veh_exps.size(0), 1))[:,:,None]
        sel_veh_subs = (sel_cur_time-sel_veh_exps).clamp_(min = 0)
        sel_veh_subs[non_cus_index] = 0
        sel_veh_acc_subs = self.veh_acc_subs.gather(1, veh[:, None, None].expand(self.veh_acc_subs.size(0),
                                                                               self.veh_acc_subs.size(2), 1))
        sel_acc_subs = sel_veh_subs + sel_veh_acc_subs
        veh_acc_subs = self.veh_acc_subs.clone().cuda()
        acc_subs = veh_acc_subs.scatter(1, veh[:, None, None], sel_acc_subs)


        sel_cur_time[non_cus_index]= sel_cur_time[non_cus_index] + 0.1

        cur_time = self.veh_cur_time.clone().cuda()
        cur_time = cur_time.scatter(1, veh[:,None,None], sel_cur_time)



        cur_veh_rema_capa = self.veh_rema_capa.gather(1, veh[:,None,None].expand(self.veh_rema_capa.size(0),  self.veh_rema_capa.size(2),1))
        veh_arri = selected[:,:,None].gather(1, veh[:,None,None].expand(selected.size(0),  1,1))
        veh_arri_dems= self.dems.transpose(1,2).gather(1, veh_arri.expand(selected.size(0), 1, 1))
        cur_veh_rema_capa -= veh_arri_dems
        veh_rema_capa =self.veh_rema_capa.clone().cuda()
        veh_rema_capa = veh_rema_capa.scatter(1, veh[:,None,None], cur_veh_rema_capa)

        if self.visited_.dtype == torch.uint8:
            visited_ = self.visited_.scatter(-1, selected[torch.arange(batch_size), veh][:, None, None].expand_as(self.visited_[:, :, 0:1]), 1) # 512*1*LOC


            prev_delivery = self.veh_masks.clone().cuda()
            now_delivery = prev_delivery.gather(1, veh[:,None,None].expand(prev_delivery.size(0), 1, prev_delivery.size(2))) # 512*1*n_loc


            now_delivery = now_delivery.scatter(-1, new_delivery[:, None, None], 1).squeeze()
            delivery = prev_delivery
            delivery = delivery.scatter(1, veh[:,None,None].expand(prev_delivery.size(0), 1, prev_delivery.size(2)),now_delivery[:,None,:].expand(prev_delivery.size(0),veh_num,prev_delivery.size(2)))

        else:
            visited_ = mask_long_scatter(self.visited_, selected[torch.arange(batch_size), veh])

    
        return self._replace(
            veh_prev_a=prev_a, visited_=visited_,
            lengths=acc_lengths,  i=self.i + 1, veh_masks=delivery,veh_rema_capa=veh_rema_capa,veh_cur_time=cur_time,
            veh_acc_late=acc_late, veh_acc_subs = acc_subs
        )

    def all_finished(self):
        return self.visited.all()

    def get_finished(self):
        return self.visited.sum(-1) == self.visited.size(-1)

    def get_current_node(self):
        return self.veh_prev_a

    def get_acc_late(self):
        return self.veh_acc_late
    def get_acc_subs(self):
        return self.veh_acc_subs

    def get_acc_lengths(self):
        return self.lengths


    def get_mask(self, veh):

        if self.visited_.dtype == torch.uint8:
            visited_loc = self.visited_ # [batch_size, 1, n_loc]
        else:
            visited_loc = self.visited_[:, None, :]  # [batch_size, 1, n_loc]


        all_veh_delivery = self.veh_masks # 512* n_veh * n_loc
        delivery = all_veh_delivery.gather(1, veh[:,None,None].expand(all_veh_delivery .size(0), 1,
                                                                       all_veh_delivery .size(2)))  # 512*1*n_loc

        cur_veh_rema_cap = self.veh_rema_capa.gather(1, veh[:,None,None].expand(self.veh_rema_capa.size(0), 1,self.veh_rema_capa.size(2)))
        cur_veh_time = self.veh_cur_time.gather(1, veh[:,None,None].expand(self.veh_cur_time.size(0), 1,self.veh_cur_time.size(2)))

        apt = cur_veh_time < self.aprs



        mask_loc = visited_loc.to(self.veh_masks.device) | (1 - delivery) | (cur_veh_rema_cap < self.dems) | apt

        non_cus_index = mask_loc.all(-1).squeeze()
        check_veh = veh[non_cus_index][:,None,None]

        mask_loc[non_cus_index] = mask_loc[non_cus_index].scatter_(-1, check_veh, 0)


        return mask_loc > 0, non_cus_index

    def get_veh_mask(self,num_veh):



        veh_mask_l = []
        for i in range (num_veh):

            mask_base_= self.veh_masks[:, i, :][:, None, :]
            if self.visited_.dtype == torch.uint8:
                visited_loc = self.visited_  # [batch_size, 1, n_loc]
            else:
                visited_loc = self.visited_[:, None, :]  # [batch_size, 1, n_loc]

            mask_veh_ = visited_loc.to(mask_base_.device) | (1 - mask_base_)

            veh_mask_ = mask_veh_.sum(-1) == mask_veh_.size(-1)
            veh_mask_l.append(veh_mask_)



        veh_mask = torch.cat(veh_mask_l,1) # 512*3



        all_done_index = self.visited_.all(-1).squeeze()
        veh_mask[all_done_index] = 0

        return veh_mask
    
    def construct_solutions(self, actions):
        return actions
