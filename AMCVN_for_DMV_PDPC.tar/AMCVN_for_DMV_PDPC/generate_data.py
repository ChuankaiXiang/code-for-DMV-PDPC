import os

from utils.data_utils import check_extension, save_dataset
import torch
import pickle
import argparse
import math
import pandas as pd
import numpy as np
import random

def generate_hcvrp_data(dataset_size,
        cust_count,
        veh_count,
        veh_capa,
        veh_speed,
        cust_loc_range,
        cust_dem_range,
        horizon,
        cust_dur_range,
        tw_ratio,
        cust_tw_range,
        deg_of_dy,
        deg_of_veh_dy,
        d_early_ratio):
    data = []
    path = 'data/transportation_nodes/node.csv'
    for seed in range(24601, 24611):
        torch.manual_seed(seed)


        locations = pd.read_csv(path, header=0,
                                usecols=["Longitude", "Latitude"
                                         ]).values
        locations = np.array(locations)
        # 先一步标准化一下下
        locations[:, 0] = locations[:, 0] - 73.5
        locations[:, 0] = locations[:, 0] * 10000
        locations[:, 1] = locations[:, 1] * 10000
        dy_veh_count = int(veh_count * deg_of_veh_dy)
        sel_node_num = cust_count * 2 + dy_veh_count * 2+2

        selected_points = locations[:sel_node_num, :]
        for i in range(sel_node_num, len(locations)):
            r = random.randint(0, i)
            if r < sel_node_num:
                selected_points[r, :] = locations[i, :]

        nodes = torch.from_numpy(selected_points).float()

        locs = nodes[None,:cust_count * 2, :]

        dy_veh_start = nodes[None,cust_count * 2:cust_count * 2 + dy_veh_count, :]
        dy_veh_destination = nodes[None,cust_count * 2 + dy_veh_count:cust_count * 2 + dy_veh_count * 2, :]
        st_veh_start = nodes[None,cust_count * 2 + dy_veh_count * 2:cust_count * 2 + dy_veh_count * 2 + 1, :].expand(1,
            veh_count - dy_veh_count, 2)

        #自有车辆起点终点不同
        # st_veh_destination = nodes[None,cust_count * 2 + dy_veh_count * 2 + 1:cust_count * 2 + dy_veh_count * 2 + 2,
        #                      :].expand(1,veh_count - dy_veh_count, 2)

        #自有车辆起点终点相同
        st_veh_destination = st_veh_start

        veh_start = torch.cat((st_veh_start, dy_veh_start), 1)
        veh_destination = torch.cat((st_veh_destination, dy_veh_destination), 1)


        dems_pick = torch.randint(*cust_dem_range, (dataset_size,cust_count, 1), dtype=torch.float)
        dems_del = - dems_pick
        dems = torch.cat((dems_pick, dems_del), 1)
        durs = torch.randint(*cust_dur_range, (dataset_size,cust_count * 2, 1), dtype=torch.float)

        if isinstance(deg_of_dy, float):
            is_dyn = torch.empty((dataset_size,cust_count, 1)).bernoulli_(deg_of_dy)
        elif len(deg_of_dy) == 1:
            is_dyn = torch.empty(deg_of_dy).bernoulli_(deg_of_dy[0])
        else:  # tuple of float
            ratio = torch.tensor(deg_of_dy)[torch.randint(0, len(deg_of_dy), (1,), dtype=torch.int64)]
            is_dyn = ratio[:, None].expand((dataset_size,cust_count, 1)).bernoulli()

        if isinstance(d_early_ratio, float):
            is_dyn_e = torch.empty((dataset_size,cust_count, 1)).bernoulli_(d_early_ratio)
        elif len(d_early_ratio) == 1:
            is_dyn_e = torch.empty((dataset_size,cust_count, 1)).bernoulli_(d_early_ratio[0])
        else:
            ratio = torch.tensor(d_early_ratio)[
                torch.randint(0, len(d_early_ratio), (1,), dtype=torch.int64)
            ]
            is_dyn_e = ratio[:, None].expand((dataset_size,cust_count, 1)).bernoulli()

        pick_aprs = is_dyn * is_dyn_e * torch.randint(1, horizon // 3 + 1, (dataset_size,cust_count, 1), dtype=torch.float) \
                    + is_dyn * (1 - is_dyn_e) * torch.randint(horizon // 3 + 1, 2 * horizon // 3 + 1, (dataset_size,cust_count, 1),
                                                              dtype=torch.float)
        del_aprs = pick_aprs
        aprs = torch.cat((pick_aprs, del_aprs), 1)

        dy_veh_count = int(veh_count * deg_of_veh_dy)
        veh_st_aprs = torch.tensor(0, dtype=torch.float).expand(dataset_size,veh_count - dy_veh_count, 1)
        veh_st_exps = torch.tensor(horizon, dtype=torch.float).expand(dataset_size,veh_count - dy_veh_count, 1)
        veh_dy_aprs = torch.randint(1, horizon // 3 + 1, (dataset_size,dy_veh_count, 1), dtype=torch.float)
        veh_dy_exps = torch.randint(horizon // 2 + 1, horizon, (dataset_size,dy_veh_count, 1), dtype=torch.float)
        veh_aprs = torch.cat((veh_st_aprs, veh_dy_aprs), 1)
        veh_exps = torch.cat((veh_st_exps, veh_dy_exps), 1)
        shuf_veh_dys = torch.cat((veh_aprs, veh_exps), -1)
        shuff = torch.randperm(shuf_veh_dys.size(1))
        shuf_veh_dys = shuf_veh_dys[:,shuff,:]
        veh_aprs = shuf_veh_dys[:,:, 0]
        veh_exps = shuf_veh_dys[:,:, 1]

        veh_exps_index = veh_exps == horizon
        veh_exps[veh_exps_index] = math.inf  # 自有车辆赋值一个大值作为过期时间
        veh_start = veh_start[:,shuff,:]
        veh_destination = veh_destination[:,shuff,:]


        if isinstance(tw_ratio, float):
            has_tw = torch.empty((dataset_size,cust_count, 1)).bernoulli_(tw_ratio)
        elif len(tw_ratio) == 1:
            has_tw = torch.empty((dataset_size,cust_count, 1)).bernoulli_(tw_ratio[0])
        else:  # tuple of float
            ratio = torch.tensor(tw_ratio)[torch.randint(0, len(tw_ratio), (1,), dtype=torch.int64)]
            has_tw = ratio[:, None].expand((dataset_size,cust_count, 1)).bernoulli()

        tws_pick = (1 - has_tw) * torch.full((dataset_size, cust_count, 1), horizon) \
                   + has_tw * torch.randint(*cust_tw_range, (dataset_size, cust_count, 1), dtype=torch.float)
        tws_deli = (1 - has_tw) * torch.full((dataset_size, cust_count, 1), horizon) \
                   + has_tw * torch.randint(*cust_tw_range, (dataset_size, cust_count, 1), dtype=torch.float)
        tws = torch.cat((tws_pick, tws_deli), 1)

        centroid = torch.mean(veh_start, dim=1)
        pick_tts = (centroid[:,None, None, :] - locs[:,:cust_count, None, :]).pow(2).sum(-1).pow(0.5) / veh_speed
        del_tts_ = (locs[:,:cust_count, None, :] - locs[:,cust_count:, None, :]).pow(2).sum(-1).pow(0.5) / veh_speed
        del_tts = pick_tts + del_tts_

        pick_rdys = has_tw[:,:cust_count, :] * (aprs[:,:cust_count, :] + torch.rand(dataset_size,cust_count, 1) * (
                    horizon - torch.max(pick_tts + durs[:,:cust_count, :], tws[:,:cust_count, :]) - aprs[:,:cust_count, :]))

        del_rdys = pick_rdys + del_tts
        rdys = torch.cat((pick_rdys, del_rdys), 1)

        rdys.floor_()
        ldts = rdys + tws

        ##normalize###
        loc_scl, loc_off = torch.cat((locs, veh_start, veh_destination), 1)[:,:, :].max().item(), torch.cat(
            (locs, veh_start, veh_destination), 1)[:,:, :].min().item()
        loc_scl -= loc_off
        t_scl = ldts[:,:, :].max().item()

        locs -= loc_off
        locs /= loc_scl
        veh_start -= loc_off
        veh_start /= loc_scl
        veh_destination -= loc_off
        veh_destination /= loc_scl

        dems /= veh_capa

        durs /= t_scl
        rdys /= t_scl
        ldts /= t_scl
        aprs /= t_scl
        veh_aprs /= t_scl
        veh_exps /= t_scl



        veh_speed = torch.tensor(veh_speed, dtype=torch.float32).expand(1)

        thedata = list(zip(locs.tolist(),
                    veh_start.tolist(),
                    veh_destination.tolist(),
                    dems.tolist(),
                    durs.tolist(),
                    rdys.tolist(),
                    ldts.tolist(),
                    aprs.tolist(),
                    veh_aprs.tolist(),
                    veh_exps.tolist(),
                    veh_speed.tolist()
                           ))
        data.append(thedata)
    t = np.array(data)
    data = t.reshape(10, 11)

    return data


if __name__ == "__main__":
    CUST_COUNT = 25
    VEH_COUNT = 5
    VEH_CAPA = 200
    VEH_SPEED = 5
    HORIZON = 480
    MIN_CUST_COUNT = None
    LOC_RANGE = (0, 101)
    DEM_RANGE = (5, 41)
    DUR_RANGE = (10, 31)
    TW_RATIO = (0.25, 0.5, 0.75, 1.0)
    TW_RANGE = (30, 91)
    DEG_OF_DYN =0.4
    DEG_OF_VEH_DYN = 0.4
    APPEAR_EARLY_RATIO = (0.0, 0.5, 0.75, 1.0)

    parser = argparse.ArgumentParser()
    parser.add_argument("--filename", help="Filename of the dataset to create (ignores datadir)")
    parser.add_argument("--dataset_size", type=int, default=1, help="1/10 Size of the dataset")

    group = parser.add_argument_group("Data generation parameters")
    group.add_argument('--graph_size', "-n", type=int, default=CUST_COUNT)
    group.add_argument('--n_veh', "-m", type=int, default=VEH_COUNT)
    group.add_argument("--veh_capa", type=int, default=VEH_CAPA)
    group.add_argument("--veh_speed", type=int, default=VEH_SPEED)
    group.add_argument("--horizon", type=int, default=HORIZON)
    group.add_argument("--min_cust_count", type=int, default=MIN_CUST_COUNT)
    group.add_argument("--loc_range", type=int, nargs=2, default=LOC_RANGE)
    group.add_argument("--dem_range", type=int, nargs=2, default=DEM_RANGE)
    group.add_argument("--dur_range", type=int, nargs=2, default=DUR_RANGE)
    group.add_argument("--tw_ratio", type=float, nargs='*', default=TW_RATIO)
    group.add_argument("--tw_range", type=int, nargs=2, default=TW_RANGE)
    group.add_argument("--deg_of_dyna", type=float, nargs='*', default=DEG_OF_DYN)
    group.add_argument("--deg_of_veh_dyna", type=float, nargs='*', default=DEG_OF_VEH_DYN)
    group.add_argument("--appear_early_ratio", type=float, nargs='*', default=APPEAR_EARLY_RATIO)

    opts = parser.parse_args()
    data_dir = 'data'
    problem = 'MVPDPC_cus_veh_DY_TW_CA_test2'
    datadir = os.path.join(data_dir, problem)
    os.makedirs(datadir, exist_ok=True)
    seed = 24610
    np.random.seed(seed)
    print(opts.dataset_size, opts.graph_size)
    filename = os.path.join(datadir, '{}_v{}_{}_seed{}.pkl'.format(problem, opts.n_veh, opts.graph_size, seed))

    dataset = generate_hcvrp_data(opts.dataset_size,
        opts.graph_size,
        opts.n_veh,
        opts.veh_capa,
        opts.veh_speed,
        opts.loc_range,
        opts.dem_range,
        opts.horizon,
        opts.dur_range,
        opts.tw_ratio,
        opts.tw_range,
        opts.deg_of_dyna,
        opts.deg_of_veh_dyna,
        opts.appear_early_ratio)
    print(dataset[0])
    save_dataset(dataset, filename)



